package com.sci.springboot.javatest.controller;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.sci.springboot.javatest.model.Donation;
import com.sci.springboot.javatest.service.UserService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = UserController.class, secure = false)
public class UserControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private UserService userService;

	Donation mockDonation = new Donation ("donation1", "Cash", "30K");

	String exampleDonationJson = "{\"name\":\"Cash\",\"description\":\"30K\"}";

	@Test
	public void createUserDonation() throws Exception {
		Donation mockDonation = new Donation("2", "Even and Prime number", "2");
		Mockito.when(
				userService.addDonation(Mockito.anyString(),
						Mockito.any(Donation.class))).thenReturn(mockDonation);

		// Send Donation as body to the path /users/user1/donations
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/users/user1/donations")
				.accept(MediaType.APPLICATION_JSON).content(exampleDonationJson)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.CREATED.value(), response.getStatus());

		assertEquals("http://localhost/users/user1/donations/2",
				response.getHeader(HttpHeaders.LOCATION));

	}

	@Test
	public void retrieveDetailsForUser() throws Exception {

		Mockito.when(
				userService.retrieveDonations(Mockito.anyString(),
						Mockito.anyString())).thenReturn(mockDonation);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/users/user1/donations/donation1").accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "{id:donation1,name:Cash,description:30K}";

		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}

}