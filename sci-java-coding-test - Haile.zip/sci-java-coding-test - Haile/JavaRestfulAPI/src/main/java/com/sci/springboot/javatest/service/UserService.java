package com.sci.springboot.javatest.service;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//import org.apache.catalina.User;
import org.springframework.stereotype.Component;

import com.sci.springboot.javatest.model.Donation;
import com.sci.springboot.javatest.model.SCIUser;

@Component
public class UserService {

	private static List<SCIUser> users = new ArrayList<>();

	static {
		//Instantiating Donations with mock inputs
		Donation donation1 = new Donation ("donation1", "blanket", "Brand x blakets to be delivered to site Y");
		Donation donation2 = new Donation("donation2", "Dry Food", 
		 "Various dry food items including Biscuits, Porridge powder , Bread, and Sugar");
				
		Donation donation3 = new Donation("donation3", "Cash donation of £20K", 
		" Cash donation to be paid to Save the Children International in three installements");
		Donation donation4 = new Donation("donation4", "miscellaneous",
				"Various types of donations");
// initialising and adding Users with mock user details 
		SCIUser john = new SCIUser("user1", "John B.",
				"Manager Company X", new ArrayList<>(Arrays
						.asList(donation1, donation2, donation3, donation4)));

		SCIUser haile = new SCIUser("user2", "Haile Y",
				"Programmer Trainer", new ArrayList<>(Arrays
				.asList(donation1, donation2, donation3, donation4)));

		users.add(john);
		users.add(haile);
	}
// Key services of the UserService class
	public List<SCIUser> retrieveAllUser() {
		return users;
	}

	public SCIUser retrieveUser(String userId) {
		for (SCIUser user : users) {
			if (user.getId().equals(userId)) {
				return user;
			}
		}
		return null;
	}

	public List<Donation> retrieveDonations(String userId) {
		SCIUser user = retrieveUser(userId);

		if (user == null) {
			return null;
		}

		return user.getDonations();
	}

	public Donation retrieveDonations(String userId, String donationId) {
		SCIUser user = retrieveUser(userId);

		if (user == null) {
			return null;
		}

		for (Donation donation : user.getDonations()) {
			if (donation.getId().equals(donationId)) {
				return donation;
			}
		}

		return null;
	}

	private SecureRandom random = new SecureRandom();

	public Donation addDonation(String userId, Donation donation) {
		SCIUser user = retrieveUser(userId);

		if (user == null) {
			return null;
		}

		String randomId = new BigInteger(320, random).toString(32);
		donation.setId(randomId);

		user.getDonations().add(donation);

		return donation;
	}
}