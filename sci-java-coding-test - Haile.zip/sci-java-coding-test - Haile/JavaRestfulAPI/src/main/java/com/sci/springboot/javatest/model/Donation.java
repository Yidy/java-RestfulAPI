package com.sci.springboot.javatest.model;



public class Donation {
	private String id;
	private String name;
	private String description;

	public Donation() { // default constructor 

	}

	public Donation (String id, String name, String description) {// constructor with arguments
		super();
		this.id = id;
		this.name = name;
		this.description = description;
	}
// Getters and Setter methods
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return String.format(
				"Donation [id=%s, name=%s, description=%s]", id, name,
				description);
	}
// Property hashing (id hashing)
	@Override
	public int hashCode() {
		final int prime = 51;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Donation other = (Donation) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}