package com.sci.springboot.javatest.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.sci.springboot.javatest.service.*;
import com.sci.springboot.javatest.model.*;

/*Please read the Read_me file in the projects folder for code logic and implementation. 
Or contact me via yidnekr@yahoo.com for any further clarifications*/
@RestController
public class UserController {

	@Autowired  // Spring autowiring facility 
	private UserService userService;
// POST mapping
	@PostMapping("/users/{userId}/donations")
	public ResponseEntity<Void> registerUserForDonation(
			@PathVariable String userId, @RequestBody Donation newDonation) {

		Donation donation = userService.addDonation(userId, newDonation);

		if (donation == null)
			return ResponseEntity.noContent().build();

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path(
				"/{id}").buildAndExpand(donation.getId()).toUri();

		return ResponseEntity.created(location).build();
	}

	// GET Mapping
	@GetMapping ("/users")
	public List<SCIUser> retrieveAllSCIUsers (){
		return userService.retrieveAllUser();
	}
	
	@GetMapping("/users/{userId}/donations")
	public List<Donation> retrieveDonationsForUser(@PathVariable String userId) {
		return userService.retrieveDonations(userId);
	}
	@GetMapping("/users/{userId}/donations/{donationId}")
	public Donation retrieveDetailsForDonation(@PathVariable String userId,
			@PathVariable String donationId) {
		return userService.retrieveDonations(userId, donationId);
	}
	

}