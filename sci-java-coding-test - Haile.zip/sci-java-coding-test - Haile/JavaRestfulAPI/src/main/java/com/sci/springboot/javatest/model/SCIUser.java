package com.sci.springboot.javatest.model;

import java.util.List;

public class SCIUser {
	private String id;
	private String name;
	private String profession;
	private List<Donation> donations;

	//parameterized constructor

	public SCIUser(String id, String name, String profession,
			List<Donation> donations) {
		super();
		this.id = id;
		this.name = name;
		this.profession = profession;
		this.donations = donations;
	}
// Setter and Getter methods 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public List<Donation> getDonations() {
		return donations;
	}

	public void setDonations(List<Donation> donations) {
		this.donations = donations;
	}
// Property formatting 
	@Override
	public String toString() {
		return String.format(
				"SCIUser [id=%s, name=%s, Profession=%s, Donations=%s]", id,
				name, profession, donations);
	}
}